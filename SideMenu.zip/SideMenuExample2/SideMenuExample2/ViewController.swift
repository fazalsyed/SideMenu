//
//  ViewController.swift
//  SideMenuExample2
//
//  Created by syed fazal abbas on 09/05/23.
//

import UIKit

class ViewController: UIViewController {
    var lblArr = ["User","Edit Profile","Setting","About US","LogOut"]
    var imgArr = ["ic_user","ic_editProfile","ic_settings","ic_aboutus","ic_logout"]
    @IBOutlet var sideBarView: UIView!
    var isleftSideMenuOpen = false
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        sideBarView.isHidden = true
        tableView.isHidden = true
        isleftSideMenuOpen = false
        tableView.register(UINib(nibName: "CellT_MenuBar", bundle: nil), forCellReuseIdentifier: "CellT_MenuBar")
    }
    
   
    @IBAction func btnTappedLeftMenu(_ sender: UIButton) {
    tableView.isHidden = false
        sideBarView.isHidden = false
        self.tableView.bringSubviewToFront(sideBarView)
        if !isleftSideMenuOpen{
            isleftSideMenuOpen = true
            sideBarView.frame = CGRect(x: 0, y: 103, width: 4, height: 335)
            tableView.frame = CGRect(x: 0, y: 0, width: 0, height: 335)
            sideBarView.frame = CGRect(x: 0, y: 103, width: 261, height: 335)
            tableView.frame = CGRect(x: 0, y: 0, width: 261, height: 335)
        }
        else{
            tableView.isHidden = true
            sideBarView.isHidden = true
            isleftSideMenuOpen = false
            sideBarView.frame = CGRect(x: 0, y: 103, width: 4, height: 335)
            tableView.frame = CGRect(x: 0, y: 0, width: 0, height: 335)
            sideBarView.frame = CGRect(x: 0, y: 103, width: 261, height: 335)
            tableView.frame = CGRect(x: 0, y: 0, width: 261, height: 335)
        }
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lblArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MenuBar")as? CellT_MenuBar
        cell?.mylbl.text = lblArr[indexPath.row]
        cell?.myimg.image = UIImage(named: imgArr[indexPath.row])
        return cell!
    }
}
